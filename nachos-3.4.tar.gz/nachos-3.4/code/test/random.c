  #include "syscall.h"

  void main()
  {
    Print("Hello\n");
    PrintNum(MyRandom(200));
    Halt();	// Optional. Just print stats
  }