  #include "syscall.h"
  void main()
  {
    Print("Hi Piyush\n");
    Halt();	// Optional. Just print stats
  }