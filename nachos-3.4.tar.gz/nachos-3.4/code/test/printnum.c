  #include "syscall.h"

  void main()
  {
    
    PrintNum(400);
    Halt();	// Optional. Just print stats
  }